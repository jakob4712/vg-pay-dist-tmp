# Veyra Hosted Fields (Veyra Pay) — Content Security Policy guide

The Veyra Pay WooCommerce plugin loads the Veyra Pay SDK from your
configured Veyra API base URL. The SDK then dynamically injects the
Basis Theory v2 Web Elements bundle from
`https://js.basistheory.com/v3/index.js`. Basis Theory mounts
its card-input iframes from `*.basistheory.com` directly inside the
merchant checkout page (since Phase 4.12p — earlier versions used a
Veyra-origin same-origin iframe page that is now retired).

**Phase 4.12y2 (2026-05-19) update:** the plugin now also renders
Apple Pay buttons above the card iframe when the server-resolved tier
policy allows wallets (tier_1 / tier_2). Apple Pay clicks drive
`ApplePaySession` through the browser's native Apple Pay integration
with the help of files served from `https://applepay.cdn-apple.com`.
The wallet flow tokenizes through Basis Theory's `/apple-pay`
endpoint — Stripe.js still NEVER loads in the customer browser.

**F218 (2026-05-22):** Google Pay is restored through the BT-managed
wallet rail. The plugin loads `pay.google.com` only when the
server-resolved wallet policy and browser capability check allow it.

If your WordPress site sets a Content Security Policy, you must allow
the Veyra origin, the Basis Theory origins, and (on tier_1/2) the
Apple wallet origin.

## Required directives

Replace `https://veyragate.com` with whatever you configured under
**WooCommerce → Settings → Payments → Veyra Hosted Fields → API base URL**.

```http
Content-Security-Policy:
  script-src  'self' https://veyragate.com https://js.basistheory.com https://*.basistheory.com https://applepay.cdn-apple.com https://pay.google.com;
  frame-src   'self' https://*.basistheory.com;
  connect-src 'self' https://veyragate.com https://*.basistheory.com;
  style-src   'self' 'unsafe-inline';
```

| Directive | Why |
|---|---|
| `script-src` | Loads `https://veyragate.com/v1/hosted-fields.js` (the card payment gateway SDK). The SDK then injects `https://js.basistheory.com/v3/index.js` (the Basis Theory Web Elements v3 bundle). `*.basistheory.com` covers tenant-specific bundle hosts the SDK may resolve at runtime. `applepay.cdn-apple.com` serves the Apple Pay JS helper bundle for Safari. `pay.google.com` serves Google's Pay API sheet when Google Pay is eligible. Wallet origins are only used when the server-resolved wallet policy allows them. |
| `frame-src`  | Basis Theory renders its PAN / expiration / CVC iframes from `*.basistheory.com`. The merchant page never embeds a Veyra-origin iframe for card capture (the same-origin iframe path was retired in Phase 4.12p; `/v1/hosted-fields/iframe` now returns 410 Gone for cached-old-SDK callers). Apple Pay opens a native browser sheet — no `frame-src` entry is required for it. |
| `connect-src`| The SDK fetches `https://veyragate.com/api/v1/public/bt-config` to get the Basis Theory public key. The merchant page's BT SDK then calls `https://api.basistheory.com/...` directly to mint token intents — and the Apple Pay driver POSTs to `https://api.basistheory.com/apple-pay/session` and `/apple-pay` for the wallet tokenization round-trip. After tokenization the WooCommerce gateway POSTs to `https://veyragate.com/api/checkout/{session_id}/pay-bt` server-side, not from the browser. |
| `style-src`  | The SDK injects scoped inline styles to brand the BT iframe wrapper. |

**Stripe domains MUST stay absent from your CSP.** The Veyra Pay
plugin never loads `https://js.stripe.com`, `https://m.stripe.com`,
or `https://api.stripe.com` from the customer browser. If you see
those origins appear in CSP-violation reports, that signals a
regression — please report it through the Veyra admin support
channel.

The Veyra Pay SDK is best-effort tolerant of stricter CSP — if you
omit `connect-src https://*.basistheory.com` the SDK will fail closed
with a `bt_tokenize_unavailable` error visible to the customer.
Allowing the BT origins explicitly is the only supported path for
live BT-canonical mode.

## Wallets on the WC plugin

As of plugin v0.4.3 the WC plugin renders Apple Pay buttons above the
card iframe when the server-resolved policy permits them. The render
gate is server-side: the plugin fetches
`/api/checkout/{session_id}/card_capture_config` which returns a
`wallets` block. The button only mounts when
`wallets.enable_wallets === true`. On tier_3 / tier_4 merchants the
server returns `enable_wallets=false`, the plugin loads zero wallet
JS, and the customer sees the card form only — preserving the
descriptor-masking strategy on the processor side.

Even with this client-side gate the server enforces a defense-in-depth
check on `POST /api/checkout/{session_id}/pay-bt`: a wallet-flagged
request against a tier_3/4 merchant is rejected with HTTP 422 and the
session row is marked `wallet_disallowed_by_policy`. A stale browser
cache or a hostile client cannot bypass the SAUCE refusal.

## Local / playground examples

When running through the WordPress Playground harness, the Veyra Pay
SDK still injects the BT v2 bundle from `js.basistheory.com`. You
cannot omit the BT origins in CSP even on a local Playground. Add the
Apple wallet origin if you want to test wallet rendering against a
tier_1 fixture merchant.

```http
Content-Security-Policy:
  script-src  'self' https://js.basistheory.com https://*.basistheory.com https://applepay.cdn-apple.com https://pay.google.com;
  frame-src   'self' https://*.basistheory.com;
  connect-src 'self' https://*.basistheory.com;
  style-src   'self' 'unsafe-inline';
```

When running through `docker-compose.test.yml` against
`https://veyragate.com`:

```http
Content-Security-Policy:
  script-src  'self' https://veyragate.com https://js.basistheory.com https://*.basistheory.com https://applepay.cdn-apple.com https://pay.google.com;
  frame-src   'self' https://*.basistheory.com;
  connect-src 'self' https://veyragate.com https://*.basistheory.com;
  style-src   'self' 'unsafe-inline';
```

## Production example

```http
Content-Security-Policy:
  default-src 'self';
  script-src  'self' https://veyragate.com https://js.basistheory.com https://*.basistheory.com https://applepay.cdn-apple.com https://pay.google.com;
  frame-src   'self' https://*.basistheory.com;
  connect-src 'self' https://veyragate.com https://*.basistheory.com;
  style-src   'self' 'unsafe-inline';
  img-src     'self' data:;
  font-src    'self';
  object-src  'none';
  base-uri    'self';
  form-action 'self';
  frame-ancestors 'self';
  upgrade-insecure-requests;
```

## Troubleshooting

- **Card fields don't appear.** Check the browser console for a CSP
  `Refused to load the script ...` message. The fix is usually to
  add `https://js.basistheory.com` (and `https://*.basistheory.com`)
  to `script-src`. The Veyra Pay SDK on its own only needs
  `https://veyragate.com` — the missing piece for stricter merchants
  is the BT v2 SDK CDN.
- **Card fields appear but tokenization fails immediately.** Check
  for a `Refused to connect to ...` console error. Allow
  `https://*.basistheory.com` in `connect-src`.
- **Iframe is blank.** Check for a `Refused to frame ...` console
  error. Allow `https://*.basistheory.com` in `frame-src`.
- **Apple Pay button doesn't appear at all.** Likely you're not on
  Safari with an Apple-Wallet-paired device, OR your tier-1/2
  merchant doesn't have an Apple Pay domain-association file deployed
  (see `docs/WALLETS_2026-05-18.md` for the BT Portal setup).

The WooCommerce admin notice that ships with the plugin links back to
this page if either the publishable key is missing or the API base
URL fails validation. No secret key is ever exposed in the admin
notice or in this document.
