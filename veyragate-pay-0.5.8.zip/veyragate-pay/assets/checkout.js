(function () {
  "use strict";

  var SAFE_EVENTS = {
    "veyragate.ready": true,
    "veyragate.resize": true,
    "veyragate.payment_succeeded": true,
    "veyragate.payment_failed": true,
    "veyragate.payment_pending": true,
    "veyragate.requires_action": true,
    "veyragate.error": true,
    "veyra.frame.ready": true,
    "veyra.frame.resize": true,
    "veyra.payment.succeeded": true,
    "veyra.payment.failed": true,
    "veyra.payment.processing": true,
    "veyra.payment.requires_action": true,
  };

  function mount(container) {
    var checkoutUrl = container.getAttribute("data-veyragate-checkout-url");
    var statusUrl = container.getAttribute("data-veyragate-status-url");
    var allowedOrigin = new URL(container.getAttribute("data-veyragate-origin") || checkoutUrl).origin;
    var orderId = container.getAttribute("data-veyragate-order-id") || "";

    container.innerHTML =
      '<div class="veyragate-pay-status" role="status">Loading secure VeyraGate checkout...</div>' +
      '<iframe title="VeyraGate checkout" allow="payment *; publickey-credentials-get *" referrerpolicy="strict-origin-when-cross-origin"></iframe>';

    var status = container.querySelector(".veyragate-pay-status");
    var frame = container.querySelector("iframe");
    frame.src = checkoutUrl;
    frame.style.width = "100%";
    frame.style.minHeight = "620px";
    frame.style.border = "0";
    frame.style.display = "block";

    window.addEventListener("message", function (event) {
      if (event.origin !== allowedOrigin) return;
      var data = event.data || {};
      if (data.source !== "veyragate.checkout" || !SAFE_EVENTS[data.type]) return;
      var payload = sanitize(data.payload || data.data || {});
      if (data.type === "veyragate.resize" || data.type === "veyra.frame.resize") {
        var height = Math.max(280, Math.min(parseInt(payload.height, 10) || 620, 1600));
        frame.style.minHeight = height + "px";
      }
      if (data.type === "veyragate.payment_succeeded" || data.type === "veyra.payment.succeeded") {
        status.textContent = "Payment received. Confirming order...";
        pollStatus(statusUrl, status, orderId);
      }
      if (data.type === "veyragate.payment_failed" || data.type === "veyra.payment.failed") {
        status.textContent = "Payment could not be completed. Please try again.";
      }
      if (data.type === "veyragate.payment_pending" || data.type === "veyra.payment.processing") {
        status.textContent = "Payment is processing...";
      }
      if (data.type === "veyragate.requires_action" || data.type === "veyra.payment.requires_action") {
        status.textContent = "Additional payment authentication is required.";
      }
      if (data.type === "veyragate.error") {
        status.textContent = payload.message || "VeyraGate checkout is unavailable.";
      }
    });
  }

  function pollStatus(statusUrl, statusElement, orderId) {
    if (!statusUrl) return;
    var attempts = 0;
    var timer = window.setInterval(function () {
      attempts += 1;
      fetch(statusUrl, { credentials: "same-origin" })
        .then(function (response) {
          return response.json();
        })
        .then(function (json) {
          var state = json.order_status || json.payment_status;
          if (state === "paid" || state === "payment_succeeded") {
            statusElement.textContent = "Order confirmed.";
            window.clearInterval(timer);
          }
          if (state === "payment_failed") {
            statusElement.textContent = "Payment failed.";
            window.clearInterval(timer);
          }
        })
        .catch(function () {
          if (attempts > 10) window.clearInterval(timer);
        });
      if (attempts > 20) window.clearInterval(timer);
    }, 3000);
    if (orderId) statusElement.setAttribute("data-veyragate-order-id", orderId);
  }

  function sanitize(payload) {
    var text = JSON.stringify(payload || {});
    if (/\b(pi|pm|ch|acct)_[A-Za-z0-9]/.test(text) || /raw[_-]?provider[_-]?response|provider[_-]?webhook[_-]?payload/i.test(text)) {
      return {};
    }
    return payload || {};
  }

  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".veyragate-pay-frame").forEach(mount);
  });
})();
