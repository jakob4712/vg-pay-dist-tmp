=== Veyra Hosted Fields for WooCommerce ===
Contributors: veyra
Tags: woocommerce, payment, checkout, hosted-fields, veyra
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 0.5.8
License: GPL-2.0-or-later

Veyra hosted card fields embedded inline into WooCommerce checkout — both classic and Cart/Checkout Blocks.

== Description ==

This plugin embeds Veyra Hosted Fields directly into the WooCommerce
payment method area on the checkout page (classic and Blocks). Veyra
owns ONLY the secure card fields; the rest of the checkout — page
layout, order summary, billing / shipping fields, and the "Place
order" button — stays exactly as WooCommerce ships it.

The integration is SAQ A by design:

* Card number / CVC / expiration are typed only inside the Veyra
  hosted-fields iframe. The merchant site's JavaScript cannot read
  them.
* Tokenisation happens BEFORE the WooCommerce form submits. The
  server-side process_payment() handler receives only safe metadata:
  payment_method_id, token_id, session_id, tokenization mode, last4,
  brand.
* No raw card data is ever stored in WooCommerce order metadata,
  logs, or notes.
* Refunds are fully supported through WooCommerce's standard
  process_refund pipeline (full and partial).

The plugin is gateway-agnostic. Three tokenisation modes are
supported:

1. `basis_theory` — live Basis Theory tokenisation
2. `basis_theory_mock` — local Basis-Theory-compatible mock (for
   tests and CI)
3. `synthetic` — pure-server fallback for dev / sandbox

== Installation ==

1. Build the distributable zip:
   `node integrations/woocommerce/build-plugin.mjs`
2. In WordPress: Plugins → Add New → Upload Plugin → choose
   `integrations/woocommerce/dist/veyragate-pay-<version>.zip`.
3. Activate the plugin.
4. Go to WooCommerce > Settings > Payments > Veyra Hosted Fields.
5. Enter the Veyra API base URL, publishable key, and secret key.
6. Add this webhook URL in the Veyra admin:
   `https://your-site.example/?wc-api=veyragate_pay`

== Cart/Checkout Blocks support ==

The plugin auto-registers as a Blocks payment method on
`woocommerce_blocks_loaded`. On a Blocks checkout page, the same
hosted fields render inside the React payment method content, and
the same Place Order button is the only CTA.

== Test-mode setup ==

The plugin works against the Veyra test environment without any code
changes:

* Configure your Veyra account in test mode.
* Use a Veyra publishable key (`pk_test_...`) and a Veyra test
  secret key (`sk_test_...`) in the plugin settings.
* Webhook deliveries are verified with `Veyragate-Signature` (HMAC-SHA256
  over `<timestamp>.<body>`, 300-second skew window).
* The checkout page loads `https://<api_base_url>/v1/hosted-fields.js`
  and mounts a sandboxed iframe at
  `https://<api_base_url>/v1/hosted-fields/iframe`.
* No card number / CVC field is ever rendered inside WordPress.

== Content Security Policy ==

If your site sets a Content Security Policy, allow the Veyra API
base URL in three directives:

```
script-src  'self' https://veyragate.com;
frame-src   'self' https://veyragate.com;
connect-src 'self' https://veyragate.com;
```

Full details: `docs/CSP.md` inside the plugin.

== Refunds ==

Refunds are issued through WooCommerce → Orders → <order> → Refund.
The plugin calls `POST <api_base_url>/api/v1/refunds` with the
stored transaction id and the refund amount. Full and partial
refunds are supported. Order notes record the refund id and amount.

== Security Notes ==

Do not modify this plugin to collect raw PAN or CVC in WordPress.
The Veyra hosted-fields iframe is the payment boundary.

== Changelog ==

= 0.5.8 =
* Fix: the Apple Pay button now paints immediately once wallets are confirmed for the store, instead of waiting on the Google Pay SDK. Previously a slow or blocked pay.google.com load could stall the entire wallet surface so the Apple Pay button never appeared; Google Pay readiness now runs in the background with a watchdog and is added alongside Apple Pay only if/when the device is ready.
* Version bump forces browsers and CDNs to re-fetch the checkout scripts (cache-bust for the 0.5.7 same-origin proxy hotfix).
* No change to the card lane, the Basis Theory boundary, or the session/charge wire shape.

= 0.5.7 =
* New: Apple Pay express checkout. The Apple Pay button now renders above the card fields on checkout, and (optionally) in a slide-out mini-cart drawer, for stores whose payment policy allows wallets. The button self-hides on non-Apple devices and stays dark unless wallets are enabled for the store.
* New: an express order + session is minted server-side from the cart so the wallet button has an authoritative amount up front; the order is created before the charge so completion (stock, emails, fulfillment) runs through the normal WooCommerce lifecycle.
* The wallet charge reuses the existing checkout session for an unchanged amount (one chargeable session per order) and re-mints only when the cart total actually changes — no double-charge window on re-renders or repeated taps.
* Mini-cart wallet is off by default; enable it under WooCommerce → Settings → Payments → Veyra (and set the drawer container selector for your theme if needed).
* No change to the existing card lane, the Basis Theory combined CardElement, the card-brand detection, the SAQ-A boundary, or the session-create/confirm wire shape. Card data never enters WordPress.

= 0.5.6 =
* Fix: a multi-byte character (emoji / accented product name) in the cart summary could be split by byte-based truncation, producing invalid UTF-8 that made the session-create request body fail to encode and the checkout error with "Could not create a Veyra checkout session". Cart-summary truncation is now multi-byte safe (mb_substr).
* Fix: every order-metadata value/key the plugin sends is now clamped (value <=500, key <=40) and the bag is capped under the server limit, so an unusually long product name, store title, customer name, or address line can no longer fail a customer's checkout.
* Fix: guard against an invalid-UTF-8 body silently encoding to false (degrade to a valid body instead of an empty one).
* No change to the Basis Theory combined CardElement, the card-brand detection, the SAQ-A boundary, or the existing session-create/confirm wire shape.

= 0.5.5 =
* 2026-06-05 — Single-click Place Order on the card lane. Previously the customer had to click "Place Order" twice: the first click fired the asynchronous tokenization and aborted the in-flight submit, and only the second click — once the hidden Basis Theory token-intent field was populated — actually placed the order. The classic adapter's `tokenize()` is now a pure tokenize-and-populate step (it no longer submits the form itself), and every submit path re-enters the checkout pipeline exactly once via a shared `resubmitCheckout()` helper that re-clicks the WooCommerce Place Order button after the token-intent lands. This removes the double-click AND closes a latent double-submit (the old internal native form submit plus a caller-side submit could fire two submissions on a custom-checkout pipeline). Works on standard WooCommerce AJAX checkout and on custom-checkout plugins (Checkout Form Designer, Beaver Builder). Discovered against apexpeptidesupply.com 2026-06-05.
* No change to the Basis Theory combined CardElement, the card-brand detection, the SAQ-A boundary, or the existing session-create/confirm wire shape.

= 0.5.4 =
* 2026-06-05 — Stop refusing legit BT token-intent UUIDs as "looks like a card number." The defensive guard at `process_payment()` stripped non-digit characters from every token field and refused any candidate whose stripped digit count reached 12 — but a BT token-intent UUID like `9f1505e0-415a-435c-85c3-beabd3c9c8b6` strips to 18 digits even though its longest CONTIGUOUS digit run is 4 ("1505"). Result: every legit charge was failed at the guard with the order note "Refusing token fields that look like a card number." Switch the guard to `preg_match('/\d{12,}/', ...)` so it only matches 12+ contiguous digits (the actual shape of a card PAN); UUIDs slip past, real card numbers still get refused. Discovered against apexpeptidesupply.com 2026-06-05.
* No change to the Basis Theory combined CardElement, the card-brand detection, the SAQ-A boundary, or the existing session-create/confirm wire shape.

= 0.5.3 =
* 2026-06-05 — Custom-checkout submit-event compatibility. The classic adapter now binds an ADDITIONAL native `submit` listener on the checkout form on top of the existing jQuery `checkout_place_order_<gateway_id>` filter. Custom-checkout plugins (Checkout Form Designer and similar) replace WooCommerce's standard AJAX submit pipeline with their own — the `checkout_place_order_*` filter is never fired there, so the BT token-intent was never minted before submit and `validate_fields()` blocked the order with "Please complete your card details before placing the order." The native-submit fallback gates on `data-veyragate-pay-native-bound` so it does not stack across WC `updated_checkout` fragment swaps, and short-circuits when the token-intent field is already populated so the standard wc_checkout flow remains the primary path on standard checkout pages. Discovered against apexpeptidesupply.com (Checkout Form Designer).
* No change to the Basis Theory combined CardElement, the card-brand detection, the SAQ-A boundary, or the existing session-create/confirm wire shape.

= 0.5.2 =
* 2026-06-04 — Custom-checkout compatibility. The hosted-fields SDK + classic adapter now also enqueue from `woocommerce_review_order_before_payment` and `woocommerce_after_checkout_form`, so checkout pages rendered by custom-checkout plugins (Checkout Form Designer, CheckoutWC, custom theme overrides) — where `is_checkout()` returns false at `wp_enqueue_scripts` time — get the SDK loaded and the iframe mounted. WP dedupes the enqueue by handle, so the standard checkout flow is unchanged. New `veyragate_pay_force_enqueue_checkout` filter for site-specific escape hatches.
* No change to the Basis Theory combined CardElement, the card-brand detection, the SAQ-A boundary, or the existing session-create/confirm wire shape.

= 0.5.1 =
* 2026-06-04 — Wallet-shape parity on the card lane. The session-create call now forwards `billing_details` and `shipping_details` (name + email + phone + full address) sourced from WooCommerce's own checkout form fields (`$order->get_billing_*()` / `get_shipping_*()`). The server forwards them onto the Stripe PaymentIntent's `payment_method_data[billing_details]` so the card-lane wire shape matches what Apple Pay already sends. This unblocks AMEX authorization on masked storefronts (AMEX issuers hard-decline card-not-present without AVS data). NO UI change — the Veyra Pay iframe stays card-only (number + expiration + CVC); the new fields come from WooCommerce's existing billing/shipping form. Shipping falls back to billing when the order has no shipping address (virtual / digital orders).
* No change to the Basis Theory combined CardElement, the card-brand detection, or the SAQ-A boundary. No PAN / CVC flows into the new fields.

= 0.5.0 =
* 2026-06-01 — Card-only masked checkout. The server-side confirmation now calls `POST <api_base_url>/api/v1/checkout_sessions/confirm` (secret-key authenticated) with the `session_id` in the JSON body, replacing the older `POST /api/checkout/{session_id}/pay-bt` URL form. The confirm body carries `session_id`, `basis_theory_token_intent_id`, `card_summary`, `customer_email`, and `idempotency_key`. This is the card lane: it never sends a wallet flag.
* 3-D Secure handoff. When the confirmation returns `status: requires_action` with a `redirect_url`, the order is left un-completed and the customer is redirected to the Veyra-hosted verification page (WooCommerce `result=success` + `redirect`). The order completes on the verification return / async reconciliation. A `requires_action` outcome without a redirect URL parks the order on-hold for webhook reconciliation.
* Full order context on the checkout session. The session-create call now sends a cart summary (`cart_lines`, e.g. "1x Coat Gloss Bites; 2x Bowl Oil"), the shipping address (`ship_line1` / `ship_city` / `ship_state` / `ship_zip`), customer contact (`cust_phone` / `cust_name`), and source labels (`src_brand` / `src_route`) as session metadata. This stays on the Veyra side for records, risk, and operations — it is never forwarded to the card network. The order references `wc_order_id`, `wc_order_number`, and `wc_order_key` replace the old `vg_woocommerce_*` keys.
* New "Masked channel tag" gateway setting. When set (by your Veyra account manager), the value is sent as the session `channel`. Operations-only label — never sent to the card network, never shown to customers. The value is normalized to lowercase letters/numbers/underscores (max 60) both at save time (Settings API `validate_channel_field`) and again before send, so a malformed entry (spaces, uppercase, hyphens — e.g. "Acme Masked") can never reject the session-create and fail checkout; it is coerced to a valid tag (e.g. `acme_masked`).
* Refund and webhook reconciliation now resolve by the checkout session id stored on the order (`_veyragate_session_id`), and the webhook reads the `wc_order_id` order reference (with a session-id fallback) so order updates bind reliably.
* No change to the Basis Theory combined CardElement, the card-brand detection, or the SAQ-A boundary. AMEX is accepted on the card lane (CVC is forwarded).

= 0.4.9 =
* 2026-05-25 — trust-strip / assurance-microcopy painter and admin "Show trust strip" checkbox removed. The customer surface no longer renders "Encrypted in your browser", "PCI-DSS compliant", or "Refunds processed within ..." rows (the helper in the Veyra SDK was neutered in the upstream F286 cleanup; this release strips the matching plugin-side dead code). Descriptor disclosure ("Your bank will show a charge from {merchant}") is untouched.
* Save-changes button on the gateway settings form now binds a `change`-event handler so the button enables only after the merchant edits a field (WC core respects `:disabled` but did not reflect the dirty-state visually).
* SQLite-environment notice suppression: when running against the WordPress Playground SQLite database, optional `mysqli`-flavoured warnings emitted by Woo's compat layer no longer pollute Playwright runs. Gate the notice via `define( 'WC_VEYRAGATE_SUPPRESS_SQLITE_NOTICES', true );` in `wp-config.php`.
* Removed double-load risk of `hosted-fields.js`: the gateway's `wp_enqueue_script('veyragate-pay-sdk', ...)` is now idempotent and the Blocks integration reuses the same handle (`veyragate-pay-sdk`) instead of registering a fresh one.

= 0.4.8 =
* Conversion polish wave. Descriptor disclosure ("Your bank will show a charge from {merchant}") renders below the BT card iframe. Tier_3 / tier_4 stores can pass the mask-pool descriptor via `data-veyra-descriptor` so the disclosure matches the bank-statement string the customer actually sees.
* Loading shimmer over the BT iframe mount target until the SDK fires `ready`, eliminating the brief "empty box" beat between DOMContentLoaded and BT's first paint (~150-400ms cold).
* Sticky Pay-button container on mobile viewports (≤640px). The Place Order button gains `data-veyra-sticky-pay="1"` on render so customers never scroll past the iframe to pay.
* Smoother focus animation on the BT iframe wrapper. A 3px slate-tinted ring fades in via `:focus-within` the moment the customer clicks into the iframe.
* Persisted last-payment-method in localStorage. When both card + ACH plugins are active, return visitors land on the same lane they used last.
* Polished wallet button: 48px min-height (WCAG 2.5.5), hover lift, focus-visible outline, subtle box-shadow.
* Onboarding hook: `document` now dispatches `veyragate_pay:abandonment` when a customer interacts with the card form but leaves before tokenizing. Merchants can wire their own GA4 / Klaviyo / etc. listeners.
* 2026-05-25 cleanup: trust-strip / assurance-microcopy painter ("Encrypted in your browser", "PCI-DSS compliant", "Refunds processed within ...") removed from the customer surface and the plugin admin settings (the matching helper in the Veyra SDK was neutered upstream in the F286 cleanup).
* Requires hosted-fields.js v0.7.0-bt or higher (ships the `renderDescriptorDisclosure` / `onAbandonment` helpers).

= 0.4.6 =
* Follow-up to 0.4.5 (F192c): classic.js now short-circuits the re-mount cycle when the Veyra card iframe is already present in the mount target. Without this guard, WC's habit of firing multiple `updated_checkout` events in quick succession (every billing-field blur, every shipping change, every coupon toggle) caused concurrent `controller.mount()` calls to race each other's async Basis Theory mount calls, producing "Couldn't find an empty element with selector #veyra-card-... to mount on" errors. Customer-facing surface remained functional but the console noise was misleading and could prevent merchants from spotting real errors.

= 0.4.5 =
* Critical hotfix (F192): the Veyra card field never mounted on a real WooCommerce checkout because WC's `update_order_review` AJAX fired on initial page load and the `fragments[".woocommerce-checkout-payment"]` response payload re-injected the `#payment` HTML, replacing the freshly-mounted `#veyra-card-fields` element with an empty one. The customer saw a polite Pay-with-Card row but had nowhere to type their card details, and "Place order" returned a red "Please complete your card details" banner. classic.js + blocks.js now listen for `updated_checkout` and `payment_method_selected` jQuery body events and call `controller.unmount()` + `controller.mount(newTarget)` to re-attach the Basis Theory iframe to the fresh DOM target. The Veyra SDK (v0.4.4-bt) was patched in tandem to skip the second `BasisTheory().init()` call, because the BT v3 SDK is a singleton and throws "This BasisTheory instance has been already initialized" on a second init. Tier_3 launch unblocked.

= 0.4.4 =
* Fix branding leak in the gateway admin settings: the two integration-heartbeat fields previously surfaced "VeyraGate site key" + "VeyraGate site environment" + "VeyraGate admin" in their visible-to-merchant title/description strings. Per the merchant-facing brand policy, merchants only see "Veyra". The internal code identifier "VeyraGate" still ships as the package / class name / wire-protocol prefix (`Veyragate-Signature` header, `veyragate_*` DB table prefix), all of which are invisible to merchants. F102 real-world theme walk: confirmed the visible-to-merchant copy is brand-correct on Storefront, Astra, and Twenty Twenty-Four.

= 0.4.3 =
* Historical F47 note: Google Pay was temporarily removed from the WooCommerce plugin, then restored in F218 through the BT-managed wallet rail. Current bundles include Google Pay only behind the server-resolved wallet policy, browser readiness, and platform merchant configuration.

= 0.4.2 =
* Switch the Veyra hosted card form to Basis Theory's combined CardElement (single inline iframe owning card number + MM/YY + CVC). Earlier builds rendered three separate BT iframes styled to look single-line with host-managed focus auto-advance. The combined element paints the card-brand icon on the left as soon as the BIN (first 4 digits) is detected, advances focus between sub-fields natively, and reports a single `complete` flag in the change event. The `tokenIntents.create` payload simplifies from `data: { number, expiration_month, expiration_year, cvc }` to `data: cardElement` (BT's documented Option 1). Net effect: closer visual parity with the reference Truvo/Stripe Elements layout, fewer DOM nodes, no host-side auto-advance code path to maintain. No change to the SAQ-A boundary (card data still never touches Veyra-origin JS or the host page's DOM).

= 0.4.1 =
* Switch Apple Pay + Google Pay to BT-managed wallet mode (Phase 4.12y3). The plugin no longer requires a per-merchant Apple Pay merchant identifier — Basis Theory owns the Apple Pay merchant identifier + signing certificate under its managed-cert tenant. The `/apple-pay/session` POST now sends `display_name` + `domain` (window.location.host) instead of `merchant_identifier`. Google Pay still receives a platform-level Google Pay merchant id (registered once for Veyra at Google Pay & Wallet Console; sub-merchants do not enroll). Net effect: wallets become provision-once-per-platform instead of provision-per-merchant — no Apple Developer Program enrollment is needed at all.

= 0.4.0 =
* Apple Pay + Google Pay support is BT-managed and server-policy-gated. Wallet buttons render above the card iframe in both classic checkout and Cart/Checkout Blocks when the server-resolved policy allows wallets. Tier 3 may show wallets when the VeyraGate policy explicitly allows them; tier 4 remains default-off unless operator-enabled. Wallet clicks drive Basis Theory's native /apple-pay and /google-pay tokenization endpoints; Stripe.js is NOT loaded in the customer browser on any path.
* The PHP gateway forwards a new `wallet_type` field on the /pay-bt POST body so the server can apply the defensive SAUCE refusal (HTTP 422 with `wallet_disallowed_by_policy` on tier_3/4 + wallet_type).
* CSP: scripts may load from `pay.google.com` and `applepay.cdn-apple.com` for eligible wallet flows. See `docs/CSP.md` for the full list. Stripe domains remain blocked.

= 0.3.4 =
* Fix: server-side fallback to POST /api/v1/checkout_sessions now signs the cart with the canonical `cart_hash` HMAC (HMAC-SHA256 over "<amount_cents>.<currency-lower>" keyed by the merchant secret key). Without this, merchants who flip `require_cart_hash=true` on their account would see every WooCommerce-initiated checkout-session create fail with HTTP 400 `parameter_invalid`. The hash matches the server verifier in `app/api/v1/checkout_sessions/route.ts::verifyCartHash`.

= 0.3.3 =
* Fix: classic.js and blocks.js now populate veyra_basis_theory_token_intent_id and veyra_card_summary_json. Previous build only wrote legacy fields, so every live BT-canonical checkout failed validation with "Please complete your card details before placing the order."
* Best-effort legacy field mapping (last4 / brand sourced from card_summary) for back-compat with older PHP gateways.

= 0.3.2 =
* Basis Theory token rail integration as the universal customer-facing card capture path.
* Fail-closed behaviour in live mode when Basis Theory credentials are missing.
* Uninstall cleanup: gateway settings and scheduled cron events removed on plugin deletion (order metadata preserved).
* SSRF guard on backend HTTP calls.

