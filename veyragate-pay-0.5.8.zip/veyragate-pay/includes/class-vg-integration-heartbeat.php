<?php
/**
 * Veyra Pay — integration heartbeat / event dispatcher.
 *
 * Phase 4.12i — additive support for the VeyraGate checkout-integrations
 * inspector.  Lets VeyraGate see WooCommerce plugin installs and their
 * health without touching the existing gateway class.
 *
 * Lifecycle:
 *   - On plugin activation: schedule a daily WP-Cron tick.
 *   - On the cron tick: POST a sanitized heartbeat to
 *     `<api_base_url>/api/v1/integrations/heartbeat`.
 *   - On `woocommerce_thankyou`: POST a `checkout_session_created`
 *     event with the WooCommerce order id (no PII, no card data).
 *   - On plugin deactivation: unschedule the cron tick.
 *
 * Requires a `vgs_site_key` option (the publishable site key minted by
 * VeyraGate admin → Checkout Integrations).  If the option is missing
 * the heartbeat is a no-op — the plugin keeps processing payments,
 * we just don't get presence data until the operator pastes the key.
 *
 * Card numbers, tokens, customer PII, and processor secrets are never
 * sent.  The body only carries plugin version, WooCommerce version,
 * WordPress version, environment, and the optional order id.
 *
 * @package VeyraGatePay
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VEYRAGATE_PAY_HEARTBEAT_OPTION', 'veyragate_pay_site_key' );
define( 'VEYRAGATE_PAY_HEARTBEAT_ENV_OPTION', 'veyragate_pay_environment' );
define( 'VEYRAGATE_PAY_HEARTBEAT_CRON_HOOK', 'veyragate_pay_heartbeat_tick' );

/**
 * Resolve the API base URL stored alongside the gateway settings.  We
 * deliberately read the option directly so this file doesn't require
 * the gateway class.
 */
function veyragate_pay_heartbeat_api_base() {
	$settings = get_option( 'woocommerce_veyragate_pay_settings', array() );
	if ( is_array( $settings ) && ! empty( $settings['api_base_url'] ) ) {
		return rtrim( (string) $settings['api_base_url'], '/' );
	}
	return 'https://veyragate.com';
}

/**
 * Lookup the publishable site key.  Two sources, in order:
 *
 *   1. `veyragate_pay_site_key` standalone option.
 *   2. `vgs_site_key` field inside the gateway settings array.
 *
 * Returns null when nothing is configured.
 */
function veyragate_pay_heartbeat_site_key() {
	$standalone = get_option( VEYRAGATE_PAY_HEARTBEAT_OPTION, '' );
	if ( is_string( $standalone ) && strlen( $standalone ) > 0 ) {
		return $standalone;
	}
	$settings = get_option( 'woocommerce_veyragate_pay_settings', array() );
	if ( is_array( $settings ) && ! empty( $settings['vgs_site_key'] ) ) {
		return (string) $settings['vgs_site_key'];
	}
	return null;
}

function veyragate_pay_heartbeat_environment() {
	$env = get_option( VEYRAGATE_PAY_HEARTBEAT_ENV_OPTION, '' );
	if ( $env === 'live' || $env === 'test' ) {
		return $env;
	}
	$settings = get_option( 'woocommerce_veyragate_pay_settings', array() );
	if ( is_array( $settings ) && ! empty( $settings['vgs_environment'] ) ) {
		$candidate = (string) $settings['vgs_environment'];
		if ( $candidate === 'live' || $candidate === 'test' ) {
			return $candidate;
		}
	}
	return 'test';
}

/**
 * POST a JSON body to the integration endpoint.  Best-effort; failures
 * are swallowed because the WooCommerce admin should never see a fatal
 * because heartbeats are down.
 */
function veyragate_pay_heartbeat_post( $path, $body ) {
	$api = veyragate_pay_heartbeat_api_base();
	$url = $api . $path;
	$args = array(
		'body'      => wp_json_encode( $body ),
		'headers'   => array(
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
		),
		'timeout'   => 5,
		'sslverify' => true,
		'blocking'  => false, // fire-and-forget
	);
	if ( function_exists( 'wp_remote_post' ) ) {
		wp_remote_post( $url, $args );
	}
}

/**
 * Cron tick — dispatch a heartbeat.  Throttled to once per hour to
 * keep cost flat even if WP-Cron fires aggressively on a busy site.
 */
function veyragate_pay_heartbeat_tick() {
	$site_key = veyragate_pay_heartbeat_site_key();
	if ( ! $site_key ) {
		return;
	}
	$last = (int) get_option( 'veyragate_pay_heartbeat_last_ts', 0 );
	$now  = time();
	if ( ( $now - $last ) < ( 60 * 60 ) ) {
		return; // throttle
	}
	update_option( 'veyragate_pay_heartbeat_last_ts', $now, false );

	global $wp_version;
	$wc_version = defined( 'WC_VERSION' ) ? WC_VERSION : null;
	$body = array(
		'publishable_site_key' => $site_key,
		'integration_type'     => 'woocommerce_plugin',
		'version'              => defined( 'VEYRAGATE_PAY_VERSION' ) ? VEYRAGATE_PAY_VERSION : '0.0.0',
		'plugin_version'       => defined( 'VEYRAGATE_PAY_VERSION' ) ? VEYRAGATE_PAY_VERSION : '0.0.0',
		'woocommerce_version'  => $wc_version,
		'wordpress_version'    => $wp_version,
		'environment'          => veyragate_pay_heartbeat_environment(),
		'capabilities'         => array( 'classic_checkout', 'blocks_checkout' ),
		'sanitized_config'     => array(
			'home_url' => function_exists( 'home_url' ) ? home_url() : null,
		),
	);
	veyragate_pay_heartbeat_post( '/api/v1/integrations/heartbeat', $body );
}
add_action( VEYRAGATE_PAY_HEARTBEAT_CRON_HOOK, 'veyragate_pay_heartbeat_tick' );

/**
 * On every admin page load, kick off a heartbeat at most once per hour
 * — covers stores that have WP-Cron disabled.
 */
function veyragate_pay_heartbeat_on_admin_load() {
	if ( ! is_admin() ) {
		return;
	}
	veyragate_pay_heartbeat_tick();
}
add_action( 'admin_init', 'veyragate_pay_heartbeat_on_admin_load' );

/**
 * Order-completed event — fired from WooCommerce thankyou flow.  We
 * only send the order id + plugin version.  No customer PII, no card
 * data.  The sanitizer on the server drops anything that looks like a
 * token / PAN / JWT regardless.
 */
function veyragate_pay_heartbeat_on_thankyou( $order_id ) {
	$site_key = veyragate_pay_heartbeat_site_key();
	if ( ! $site_key || ! $order_id ) {
		return;
	}
	$body = array(
		'publishable_site_key' => $site_key,
		'event_type'           => 'checkout_session_created',
		'plugin_version'       => defined( 'VEYRAGATE_PAY_VERSION' ) ? VEYRAGATE_PAY_VERSION : '0.0.0',
		'order_ref'            => (string) $order_id,
		'environment'          => veyragate_pay_heartbeat_environment(),
		'payload'              => array(
			'origin'     => function_exists( 'home_url' ) ? home_url() : null,
			'wc_version' => defined( 'WC_VERSION' ) ? WC_VERSION : null,
		),
	);
	veyragate_pay_heartbeat_post( '/api/v1/integrations/events', $body );
}
add_action( 'woocommerce_thankyou', 'veyragate_pay_heartbeat_on_thankyou', 20 );

/**
 * Schedule / unschedule the daily heartbeat cron on plugin
 * activation / deactivation.  Idempotent.
 */
function veyragate_pay_heartbeat_activate() {
	if ( ! wp_next_scheduled( VEYRAGATE_PAY_HEARTBEAT_CRON_HOOK ) ) {
		wp_schedule_event( time() + 60, 'daily', VEYRAGATE_PAY_HEARTBEAT_CRON_HOOK );
	}
}
function veyragate_pay_heartbeat_deactivate() {
	$timestamp = wp_next_scheduled( VEYRAGATE_PAY_HEARTBEAT_CRON_HOOK );
	if ( $timestamp ) {
		wp_unschedule_event( $timestamp, VEYRAGATE_PAY_HEARTBEAT_CRON_HOOK );
	}
}
