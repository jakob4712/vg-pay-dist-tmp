<?php
/**
 * Veyra Hosted Fields — WooCommerce Blocks payment method integration.
 *
 * Registers Veyra Hosted Fields as a payment method for the
 * WooCommerce Cart & Checkout blocks (the React-based checkout that
 * shipped with WooCommerce 8+).
 *
 * The Blocks runtime renders our React component (see
 * assets/dist/blocks.js). The classic gateway above still drives
 * `payment_fields()` for classic checkout — both paths share token
 * metadata via the same hidden field names.
 *
 * @package VeyraGatePay
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

class WC_Blocks_VeyraGate_Pay extends AbstractPaymentMethodType {

	protected $name = 'veyragate_pay';

	public function initialize() {
		$this->settings = get_option( 'woocommerce_veyragate_pay_settings', array() );
	}

	public function is_active() {
		return ! empty( $this->settings ) && isset( $this->settings['enabled'] ) && 'yes' === $this->settings['enabled'];
	}

	public function get_payment_method_script_handles() {
		$asset_path = VEYRAGATE_PAY_PLUGIN_PATH . 'assets/dist/blocks.asset.php';
		$asset      = file_exists( $asset_path )
			? require $asset_path
			: array( 'dependencies' => array( 'wp-element', 'wp-html-entities', 'wp-i18n' ), 'version' => VEYRAGATE_PAY_VERSION );

		// Register the SDK first so the Blocks bundle can depend on it.
		// The classic adapter (`WC_Gateway_VeyraGate_Pay::enqueue_checkout_assets`)
		// uses the SAME handle (`veyragate-pay-sdk`), so the
		// `wp_script_is( ..., 'registered' )` guard prevents a duplicate
		// registration if the classic adapter ran first on the same
		// page-load (e.g. a Blocks checkout that also triggers the
		// `wp_enqueue_scripts` action for classic enqueueing).
		$api_base = isset( $this->settings['api_base_url'] ) ? untrailingslashit( $this->settings['api_base_url'] ) : 'https://veyragate.com';
		if ( ! wp_script_is( 'veyragate-pay-sdk', 'registered' ) ) {
			wp_register_script(
				'veyragate-pay-sdk',
				$api_base . '/v1/hosted-fields.js',
				array(),
				VEYRAGATE_PAY_VERSION,
				true
			);
		}

		wp_register_script(
			'veyragate-pay-blocks',
			VEYRAGATE_PAY_PLUGIN_URL . 'assets/dist/blocks.js',
			array_merge( $asset['dependencies'], array( 'veyragate-pay-sdk', 'wc-blocks-registry' ) ),
			$asset['version'],
			true
		);
		return array( 'veyragate-pay-sdk', 'veyragate-pay-blocks' );
	}

	public function get_payment_method_data() {
		return array(
			'name'            => $this->name,
			'title'           => isset( $this->settings['title'] ) ? $this->settings['title'] : __( 'Credit / debit card', 'veyragate-pay' ),
			// Customer-rendered. Default to blank; merchants can still
			// set a custom description per-store in WC settings.
			'description'     => isset( $this->settings['description'] ) ? $this->settings['description'] : '',
			'publishableKey'  => isset( $this->settings['publishable_key'] ) ? (string) $this->settings['publishable_key'] : '',
			'apiBaseUrl'      => isset( $this->settings['api_base_url'] ) ? untrailingslashit( $this->settings['api_base_url'] ) : 'https://veyragate.com',
			'supports'        => $this->get_supported_features(),
			// Descriptor + merchant name flow into the React Blocks
			// integration so it can render the descriptor disclosure
			// ("Your bank will show a charge from {name}") that the
			// classic adapter shows. Tier_3/4 merchants set the
			// descriptor to their mask-pool name.
			'merchantName'    => (string) get_bloginfo( 'name' ),
			'descriptor'      => isset( $this->settings['descriptor_override'] ) ? (string) $this->settings['descriptor_override'] : '',
		);
	}

	public function get_supported_features() {
		return array( 'products', 'refunds' );
	}
}
