<?php
/**
 * Veyra Hosted Fields for WooCommerce — uninstall cleanup.
 *
 * Runs once when WordPress fully deletes the plugin. Removes
 * gateway settings and any scheduled events the plugin registered.
 * Order metadata is intentionally PRESERVED — orders are merchant
 * records that should not vanish if the plugin is removed.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
delete_option( 'woocommerce_veyragate_pay_settings' );
wp_clear_scheduled_hook( 'veyragate_pay_heartbeat' );
// No other cron / transients used today; add cleanups here if
// the plugin ships scheduled tasks in the future.
